package com.ia;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner txtEntrada = new Scanner(System.in);
        System.out.println(Tradutor.tradutor(txtEntrada.nextLine()));
    }
}


// ∀, ∃, ¬, ∧, ∨, ->, <->

//        System.out.println("1 - Nenhum homem é extraterrestre -> " + Tradutor.tradutor("Nenhum homem é extraterrestre") + "\n\n");
//        System.out.println("2 - Há uma rena com um focinho vermelho -> " + Tradutor.tradutor("Há uma rena com um focinho vermelho") + "\n\n");
//        System.out.println("3 - Scrooge não ama nada que é estranho -> " + Tradutor.tradutor("Scrooge não ama nada que é estranho") + "\n\n");
//        System.out.println("4 - Todo mundo que ama Papai Noel gosta de renas -> " + Tradutor.tradutor("Todo mundo que ama Papai Noel gosta de renas") + "\n\n");
//        System.out.println("5 - Qualquer um que monta qualquer moto Harley é um cara durão -> " + Tradutor.tradutor("Qualquer um que monta qualquer moto Harley é um cara durão") + "\n\n");
//        System.out.println("6 - Todo motociclista pilota uma Harley ou uma BMW -> " + Tradutor.tradutor("Todo motociclista pilota uma Harley ou uma BMW") + "\n\n");
//        System.out.println("7 - Qualquer pessoa que monta um BMW é um yuppie -> " + Tradutor.tradutor("Qualquer pessoa que monta um BMW é um yuppie") + "\n\n");
//        System.out.println("8 - Todo yuppie é advogado -> " + Tradutor.tradutor("Todo yuppie é advogado") + "\n\n");
//        System.out.println("9 - Qualquer garota legal não namora alguém que é durao -> " + Tradutor.tradutor("Qualquer garota legal não namora alguém que é durao") + "\n\n");
//        System.out.println("10 - Mary é uma garota legal e John é um motociclista -> " + Tradutor.tradutor("Mary é uma garota legal e John é um motociclista") + "\n\n");
//        System.out.println("11 - John não é um advogado, entao Mary não namora John -> " + Tradutor.tradutor("John não é um advogado, entao Mary não namora John") + "\n\n");
//        System.out.println("12 - Qualquer coisa com um focinho vermelho é um palhaço ou estranho -> " + Tradutor.tradutor("Qualquer coisa com um focinho vermelho é um palhaço ou estranho") + "\n\n");


/*

Nenhum homem é extraterrestre

Há uma rena com um focinho vermelho

Scrooge não ama nada que é estranho

Todo mundo que ama Papai Noel gosta de renas

Qualquer um que monta qualquer moto Harley é um cara durão

Todo motociclista pilota uma Harley ou uma BMW

Qualquer pessoa que monta um BMW é um yuppie

Todo yuppie é advogado

Qualquer garota legal não namora alguém que é durao

Mary é uma garota legal e John é um motociclista

John não é um advogado, entao Mary não namora John

Qualquer coisa com um focinho vermelho é um palhaço ou estranho

 */
