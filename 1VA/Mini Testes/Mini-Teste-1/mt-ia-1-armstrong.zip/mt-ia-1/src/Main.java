
public class Main {

	public static void main(String[] args) {
		Grafo grafo = new Grafo();
		
		// Criação de Vértices
        grafo.addVertice("Fonte Luminosa");
        grafo.addVertice("Banco do Brasil");
        grafo.addVertice("Secretaria de Saúde");
        grafo.addVertice("Ministério Público-PE");
        grafo.addVertice("Caixa Econômica");
        grafo.addVertice("Paulo Sérgio Auto Peças");
        grafo.addVertice("Hotel Tavares Correia");
        grafo.addVertice("CEMEP");
        grafo.addVertice("Gastromed Garanhuns");
        grafo.addVertice("Garanhuns Palace");
        grafo.addVertice("Parque Euclides Dourado");
        grafo.addVertice("Mercearia Rui Barbosa");
        grafo.addVertice("Farmácia Pague Menos");
        grafo.addVertice("Restaurante Fogo na Telha");
        grafo.addVertice("Drogamédica");
        grafo.addVertice("Posto Filadélfia");
        grafo.addVertice("Bonanza");
        grafo.addVertice("Terraço Churrascaria");
        grafo.addVertice("Hospital Dom Moura");
        grafo.addVertice("Casa de Saúde Maternidade");

		// Criação de Arestas em linha reta (em ordem alfaética)
        grafo.addAresta("Banco do Brasil", "Banco do Brasil", 0, -1);
        grafo.addAresta("Bonanza", "Banco do Brasil", 198, -1);
        grafo.addAresta("Caixa Econômica", "Banco do Brasil", 243, -1);
        grafo.addAresta("Casa de Saúde Maternidade", "Banco do Brasil", 161, -1);
        grafo.addAresta("CEMEP", "Banco do Brasil", 243, -1);
        grafo.addAresta("Drogamédica", "Banco do Brasil", 150, -1);
        grafo.addAresta("Farmácia Pague Menos", "Banco do Brasil", 76, -1);
        grafo.addAresta("Fonte Luminosa", "Banco do Brasil", 367, -1);
        grafo.addAresta("Garanhuns Palace", "Banco do Brasil", 99, -1);
        grafo.addAresta("Gastromed Garanhuns", "Banco do Brasil", 159, -1);
        grafo.addAresta("Hospital Dom Moura", "Banco do Brasil", 233, -1);
        grafo.addAresta("Hotel Tavares Correia", "Banco do Brasil", 240, -1);
        grafo.addAresta("Mercearia Rui Barbosa", "Banco do Brasil", 194, -1);
        grafo.addAresta("Ministério Público-PE", "Banco do Brasil", 254, -1);
        grafo.addAresta("Parque Euclides Dourado", "Banco do Brasil", 177, -1);
        grafo.addAresta("Paulo Sérgio Auto Peças", "Banco do Brasil", 381, -1);
        grafo.addAresta("Posto Filadélfia", "Banco do Brasil", 162, -1);
        grafo.addAresta("Restaurante Fogo na Telha", "Banco do Brasil", 81, -1);
        grafo.addAresta("Secretaria de Saúde", "Banco do Brasil", 373, -1);
        grafo.addAresta("Terraço Churrascaria", "Banco do Brasil", 227, -1);
        
		/*
		 * grafo.addAresta("Fonte Luminosa", "Banco do Brasil", 367, -1);
		 * grafo.addAresta("Banco do Brasil", "Banco do Brasil", 0, -1);
		 * grafo.addAresta("Secretaria de Saúde", "Banco do Brasil", 373, -1);
		 * grafo.addAresta("Ministério Público-PE", "Banco do Brasil", 254, -1);
		 * grafo.addAresta("Caixa Econômica", "Banco do Brasil", 243, -1);
		 * grafo.addAresta("Paulo Sérgio Auto Peças", "Banco do Brasil", 381, -1);
		 * grafo.addAresta("Hotel Tavares Correia", "Banco do Brasil", 240, -1);
		 * grafo.addAresta("CEMEP", "Banco do Brasil", 243, -1);
		 * grafo.addAresta("Gastromed Garanhuns", "Banco do Brasil", 159, -1);
		 * grafo.addAresta("Garanhuns Palace", "Banco do Brasil", 99, -1);
		 * grafo.addAresta("Parque Euclides Dourado", "Banco do Brasil", 177, -1);
		 * grafo.addAresta("Mercearia Rui Barbosa", "Banco do Brasil", 194, -1);
		 * grafo.addAresta("Farmácia Pague Menos", "Banco do Brasil", 76, -1);
		 * grafo.addAresta("Restaurante Fogo na Telha", "Banco do Brasil", 81, -1);
		 * grafo.addAresta("Drogamédica", "Banco do Brasil", 150, -1);
		 * grafo.addAresta("Posto Filadélfia", "Banco do Brasil", 162, -1);
		 * grafo.addAresta("Bonanza", "Banco do Brasil", 198, -1);
		 * grafo.addAresta("Terraço Churrascaria", "Banco do Brasil", 227, -1);
		 * grafo.addAresta("Hospital Dom Moura", "Banco do Brasil", 233, -1);
		 * grafo.addAresta("Casa de Saúde Maternidade", "Banco do Brasil", 161, -1);
		 */

        // Criação de Arestas em linha real para Fonte Luminosa
        grafo.addAresta("Fonte Luminosa", "Secretaria de Saúde", -1, 75);
        grafo.addAresta("Fonte Luminosa", "Ministério Público-PE", -1, 140);
        grafo.addAresta("Fonte Luminosa", "Caixa Econômica", -1, 118);
        
        // Criação de Arestas em linha real para Secretaria de Saúde
        grafo.addAresta("Secretaria de Saúde", "Paulo Sérgio Auto Peças", -1, 71);
        grafo.addAresta("Secretaria de Saúde", "Fonte Luminosa", -1, 75);
        
        // Criação de Arestas em linha real para Paulo Sérgio Auto Peças
        grafo.addAresta("Paulo Sérgio Auto Peças", "Ministério Público-PE", -1, 151);
        grafo.addAresta("Paulo Sérgio Auto Peças", "Secretaria de Saúde", -1, 71);

        // Criação de Arestas em linha real para Ministério Público-PE
        grafo.addAresta("Ministério Público-PE", "Fonte Luminosa", -1, 140);
        grafo.addAresta("Ministério Público-PE", "Parque Euclides Dourado", -1, 99);
        grafo.addAresta("Ministério Público-PE", "Mercearia Rui Barbosa", -1, 80);
        grafo.addAresta("Ministério Público-PE", "Paulo Sérgio Auto Peças", -1, 151);

        // Criação de Arestas em linha real para Caixa Econômica
        grafo.addAresta("Caixa Econômica", "Fonte Luminosa", -1, 118);
        grafo.addAresta("Caixa Econômica", "Hotel Tavares Correia", -1, 111);

        // Criação de Arestas em linha real para Hotel Tavares Correia
        grafo.addAresta("Hotel Tavares Correia", "CEMEP", -1, 70);
        grafo.addAresta("Hotel Tavares Correia", "Caixa Econômica", -1, 111);

        // Criação de Arestas em linha real para CEMEP
        grafo.addAresta("CEMEP", "Hotel Tavares Correia", -1, 70);
        grafo.addAresta("CEMEP", "Casa de Saúde Maternidade", -1, 75);

        // Criação de Arestas em linha real para Casa de Saúde Maternidade
        grafo.addAresta("Casa de Saúde Maternidade", "Gastromed Garanhuns", -1, 120);
        grafo.addAresta("Casa de Saúde Maternidade", "CEMEP", -1, 75);

        // Criação de Arestas em linha real para Gastromed Garanhuns
        grafo.addAresta("Gastromed Garanhuns", "Casa de Saúde Maternidade", -1, 120);
        grafo.addAresta("Gastromed Garanhuns", "Mercearia Rui Barbosa", -1, 146);
        grafo.addAresta("Gastromed Garanhuns", "Garanhuns Palace", -1, 138);

        // Criação de Arestas em linha real para Mercearia Rui Barbosa
        grafo.addAresta("Mercearia Rui Barbosa", "Ministério Público-PE", -1, 80);
        grafo.addAresta("Mercearia Rui Barbosa", "Gastromed Garanhuns", -1, 146);
        grafo.addAresta("Mercearia Rui Barbosa", "Garanhuns Palace", -1, 97);
        
        // Criação de Arestas em linha real para Parque Euclides Dourado
        grafo.addAresta("Parque Euclides Dourado", "Ministério Público-PE", -1, 99);
        grafo.addAresta("Parque Euclides Dourado", "Banco do Brasil", -1, 211);

        // Criação de Arestas em linha real para Banco do Brasil
        grafo.addAresta("Banco do Brasil", "Garanhuns Palace", -1, 101);
        grafo.addAresta("Banco do Brasil", "Parque Euclides Dourado", -1, 211);
        grafo.addAresta("Banco do Brasil", "Farmácia Pague Menos", -1, 90);
        grafo.addAresta("Banco do Brasil", "Restaurante Fogo na Telha", -1, 85);

        // Criação de Arestas em linha real para Restaurante Fogo na Telha
        grafo.addAresta("Restaurante Fogo na Telha", "Drogamédica", -1, 98);
        grafo.addAresta("Restaurante Fogo na Telha", "Banco do Brasil", -1, 85);
        
        
		grafo.search();
		
		Vertice x = grafo.getVertice("Fonte Luminosa");
        System.out.println(x);
		
		
        System.out.println("\n\n\n");

		
        System.out.println(grafo);
        
        

	}
}
